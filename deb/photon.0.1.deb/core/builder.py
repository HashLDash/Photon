# Photon builder
# This script is used to generate a Photon project
# according to the target platform and preferences
# Each target is handled by its Toolchain

class Builder():
    def __init__(self, **kwargs):
        pass

